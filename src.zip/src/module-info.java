/**
 * 
 */
/**
 * 
 */
module JAVAExam {
}