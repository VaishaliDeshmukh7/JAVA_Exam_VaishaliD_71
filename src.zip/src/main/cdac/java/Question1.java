package main.cdac.java;

import java.util.*;

class Student {
	int studentId;
	String name;
	double grade;
	
	Student(int studentId,String name,double grade){
		this.studentId=studentId;
		this.name=name;
		this.grade=grade;
		
	}
public class Question1 {
	public static void main(String[] args) {
		void updateGrade(double newGrade){
			System.out.println("New Grade is:" + newGrade);
				try {
					if (newGrade<0);
					System.out.println("Grade Should not accept negative Values");
				}catch(ArithmeticException e){
					System.out.println("Division by zero is not allowed.");
				}finally {
					System.out.println("Execution completed.");
				}
				
		}
	}
}
}
	
		
		


	
				
				
				
				
				
				
				
				
				
		

				
