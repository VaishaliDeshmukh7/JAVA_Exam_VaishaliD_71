package main.cdac.java;


import java.util.*;

class patient {
    int pid;
    String Diagnosis;
    ArrayList<String> items;
    int days;

    public patient(int pid, String Diagnosis, List<String> list, int days) {
        this.pid = pid;
        this.Diagnosis = Diagnosis;
        this.items = new ArrayList<>(list);
        this.days = days;
    }

    @Override
    public String toString() {
        return "[ID: " + pid + ", Patient Name: " + Diagnosis + ", Items: " + items + ", Days" + days + "]";
    }
}

class patientManagment{
    Scanner sc = new Scanner(System.in);
    ArrayList<Patient> Patient;

    public patientManagment() {
        
        Patient= new ArrayList<>();

        Patient.add(new Patient(101, "Tanmay", "Cought",2));
        Patient.add(new Patient(102, "Sahil","Fever",10));
        Patient.add(new Patient(103, "Advait","Fever" ,3));
        Patient.add(new Patient(104, "Avantika", "Cought",2));
        
   

    void addpatient() {
        System.out.print("Enter patient ID: ");
        int id = sc.nextInt();
        sc.nextLine(); 

        System.out.print("Enter patient Name: ");
        String name = sc.nextLine(); 

        System.out.print("Enter patient Diagnosis: ");
        int num = sc.nextInt();
        sc.nextLine(); 

        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < num; i++) {
            System.out.print("Enter Item " + (i + 1) + ": ");
            list.add(sc.nextLine()); 
        }

        System.out.print("Enter Total Price: ");
        double price = sc.nextDouble();

        patient.add(new patient(pid, name,Diagnosisname,days  ));
        System.out.println("Patient Added Successfully!!");
    }

    void viewPatientId() {
        for (patient o : Patient) {
            System.out.println(o);
        }
    }

    void findpatient() {
        System.out.print("Enter patient Name: ");
        String cname = sc.nextLine();

        boolean flag = false;
        for (patient o : Pateint) {
            if (o.Patient_name.equalsIgnoreCase(cname)) { 
                System.out.println(o);
                flag = true;
            }
        }
        if (flag == false) {
            System.out.println("patient Name not Found!");
        }
    }

}

public class Question3 {
    public static void main(String[] args) {
        Scanner sc1 = new Scanner(System.in);
        patient om = new patientManagment ();

        int choice;
        do {
            System.out.println("==================================");
            System.out.println("===== patient Management System =====");
            System.out.println("==================================");
            System.out.println("1. Add patient");
            System.out.println("2. Remove patient");
            System.out.println("3. Find patient");
            System.out.println("4. Find all Patient");
            System.out.println("5. Exit");
            System.out.print("Enter Choice: ");
            choice = sc1.nextInt();

            switch (choice) {
                case 1:
                    om.addpatient();
                    break;
                case 2:
                    om.viewpatientID();
                    break;
                case 3:
                    om.findpatient();
                    break;
                case 4:
                    om.findallpatient();
                    break;
                    
                    
              
     
                case 5:
                    System.out.println("Exiting System....");
  
                    break;
                default:
                    System.out.println("Invalid Choice. Try Again!");
            }
        } while (choice != 6);
    


